from django import forms
from .models import Utilisateur

class UserCreationForm(forms.ModelForm):
    class Meta:
        model=Utilisateur
        fields=('email','phone_number','address','first_name','last_name','password')