from .models import Product, Commande
from django.shortcuts import get_object_or_404, redirect, render
from django.contrib.auth.decorators import login_required


# Create your views here.
def ProductList(request):
    products = Product.objects.all()
    return render(request, 'products.html', {'products': products})


def ShowProduct(request, pk):
    product = get_object_or_404(Product, id=pk)
    return render(request, 'product.html', {'product': product})




@login_required()
def commander(request, pk):
    commande = Commande.objects.create(user_id = request.user.id,product_id = pk)
    commande.save()
    return redirect('products')
