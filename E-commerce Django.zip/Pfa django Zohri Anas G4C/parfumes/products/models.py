from django.db import models
from django.conf import settings
from django.db.models.deletion import SET_NULL

# Create your models here.


class Product(models.Model):
    name = models.CharField(max_length=250, null=True, blank=True)
    brand = models.CharField(max_length=250, null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    price = models.DecimalField(
        max_digits=7, decimal_places=2, null=True, blank=True)
    countInStock = models.IntegerField(null=True, blank=True, default=0)
    createAt = models.DateTimeField(auto_now_add=True)
    image = models.ImageField(null=True)

    def __str__(self):
        return self.name


class Commande(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL,
                             on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    approved = models.BooleanField(default=False)
    createAt = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return str(self.id)
